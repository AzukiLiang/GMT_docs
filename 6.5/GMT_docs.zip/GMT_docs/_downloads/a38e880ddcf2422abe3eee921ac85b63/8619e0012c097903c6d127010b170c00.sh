gmt begin XY
gmt text -F+f40p+cMC+t1 -JX5c/2c -R0/5/0/2 -BWSen -B1
gmt text -F+f40p+cMC+t2 -BWSen -B1 -X7c
gmt text -F+f40p+cMC+t3 -BWSen -B1 -X-7c -Y4c
gmt text -F+f40p+cMC+t4 -BWSen -B1 -X7c
gmt end show